package study;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	//디비 접속을 하는 메소드
    public static Connection getCon() throws SQLException{
        Connection con=null;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            //당신이 접속하는 데이터베이스 접속 정보
            String url = "jdbc:oracle:thin:@localhost:1521:xe";
            //당신이 접속하는 데이터베이스 아이디 비밀번호
            con=DriverManager.getConnection(url, "scott", "tiger");
            return con;
        }catch(ClassNotFoundException ce){
            System.out.println(ce.getMessage());
            return null;
        }
    }

}
